$(document).ready(function(){

    /* Cria as vagas com 10 espaços */
    var estacionamento = new function () {
        var vaga = {
            ocupante: "",
            placaOcupante: "",
            nomeVaga: "Vaga",
            localVaga: "Terreo",
            custo: "10",
            data: new Date(),
            reservado: false,
        };
        patio = []
        patio[9] = new Array (vaga)

        for (c=0; c < patio.length; c++){
            patio.fill(vaga);
        }

    /* Preenche com vazio e ocupado todas as vagas vazias */
        if (vaga.ocupante == ""){
            for (i=0;i < patio.length; i++){
                vaga.ocupante = "Vazio"
                vaga.reservado = false
            }
        }else{
            vaga.ocupante = "Ocupado"
            vaga.reservado = true
        }

    /* Clona todas as vagas (Primeiramente todas as vagas estão vazias) */
        for (a=0;a < patio.length; a++){
        var clone = $('poscvaga');
        clone = $('poscvaga').clone();
        $(".poscvaga").append(clone);
        }

    }

});